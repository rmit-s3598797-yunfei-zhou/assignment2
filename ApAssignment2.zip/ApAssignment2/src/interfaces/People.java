//developer: JiaQi Tang  s3598284
package interfaces;

public interface People {
	public String getName();
	public void setName(String name);
	public String getPic();
	public void setPic(String pic);
	public String getStatus();
	public void setStatus(String status);
	public String getGender();
	public void setGender(String gender);
	public String getAge();
	public void setAge(String age);
	public String getState();
	public void setState(String state);
}
