//developer: YunFei Zhou s3598797
package interfaces;

public interface Relation {
	public String showRelation(String name1,String name2);
	public String getName1();
	public String getName2();
	public String getRelation();
}
