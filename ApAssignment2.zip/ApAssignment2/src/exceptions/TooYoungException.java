//developer: YunFei Zhou s3598797
package exceptions;

public class TooYoungException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String toString() {
		return "can not make friend with a young child";		
	}
}
