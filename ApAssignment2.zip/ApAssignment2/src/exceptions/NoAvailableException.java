//developer: YunFei Zhou s3598797
package exceptions;

public class NoAvailableException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String toString() {
		return "can not make someone already has husband or wife to be couple with someone else";		
	}
}
